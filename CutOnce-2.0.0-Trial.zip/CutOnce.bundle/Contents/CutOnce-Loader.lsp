;;; ============================================================================
;;; CutOnce-Loader.lsp  (TRIAL)
;;;
;;; Copyright (c) 2026 Stephen Walz. All rights reserved.
;;;
;;; CutOnce Trial: the EXPLODE / BURST warning only.
;;; To unlock the full version, reach out to stevewalz@hotmail.com
;;;
;;; Loads CutOnce into the current drawing:
;;;   1. finds the install folder
;;;   2. loads CutOnce-Config.lsp from it
;;;   3. loads CutOnce.vlx (or, for development builds only, the .lsp sources)
;;;
;;; Install folder resolution, first match wins:
;;;   - *cutonce:home* if already set before this file is loaded
;;;   - the CUTONCE_HOME environment variable (set by Install.ps1 -InstallDir)
;;;   - the folder this file is found in on the support path
;;;   - %APPDATA% or %ProgramData% \Autodesk\ApplicationPlugins\CutOnce.bundle\Contents
;;; ============================================================================

(vl-load-com)

(defun cutonce:loader-dir-ok (d)
  (and (= (type d) 'STR)
       (/= d "")
       (or (findfile (strcat (vl-string-right-trim "\\/" d) "\\CutOnce.vlx"))
           (findfile (strcat (vl-string-right-trim "\\/" d) "\\CutOnce-Config.lsp"))))
)

(defun cutonce:loader-find-home ( / f base)
  (cond
    ((and (boundp '*cutonce:home*) (cutonce:loader-dir-ok *cutonce:home*)) *cutonce:home*)
    ((cutonce:loader-dir-ok (getenv "CUTONCE_HOME")) (getenv "CUTONCE_HOME"))
    ((and (setq f (findfile "CutOnce-Loader.lsp"))
          (cutonce:loader-dir-ok (vl-filename-directory f)))
     (vl-filename-directory f))
    ((and (setq base (getenv "APPDATA"))
          (cutonce:loader-dir-ok (strcat base "\\Autodesk\\ApplicationPlugins\\CutOnce.bundle\\Contents")))
     (strcat base "\\Autodesk\\ApplicationPlugins\\CutOnce.bundle\\Contents"))
    ((and (setq base (getenv "ProgramData"))
          (cutonce:loader-dir-ok (strcat base "\\Autodesk\\ApplicationPlugins\\CutOnce.bundle\\Contents")))
     (strcat base "\\Autodesk\\ApplicationPlugins\\CutOnce.bundle\\Contents"))
  )
)

(defun cutonce:loader-load (path / r)
  (setq r (vl-catch-all-apply 'load (list path)))
  (if (vl-catch-all-error-p r)
    (progn
      (princ (strcat "\n[CutOnce] Failed to load " path ": " (vl-catch-all-error-message r)))
      nil
    )
    T
  )
)

(defun cutonce:loader-main ( / home vlx src)
  (setq home (cutonce:loader-find-home))
  (if (not home)
    (princ "\n[CutOnce] Install folder not found. Re-run Install.cmd, or set CUTONCE_HOME.")
    (progn
      (setq home (strcat (vl-string-right-trim "\\/" (vl-string-translate "/" "\\" home)) "\\"))
      (setq *cutonce:home* home)
      (if (findfile (strcat home "CutOnce-Config.lsp"))
        (cutonce:loader-load (strcat home "CutOnce-Config.lsp"))
      )
      (cond
        ((findfile (setq vlx (strcat home "CutOnce.vlx")))
         (cutonce:loader-load vlx))
        ;; Development fallback: sources next to the loader (installed with
        ;; -AllowSource) or in the repository layout.
        ((or (findfile (strcat (setq src (strcat home "src\\")) "CutOnce-Core.lsp"))
             (findfile (strcat (setq src (strcat home "..\\..\\src\\")) "CutOnce-Core.lsp")))
                  ;; order matters: the Control Center loads last and runs the
         ;; open-time check once everything else is in place
         (and (cutonce:loader-load (strcat src "CutOnce-Core.lsp"))
              (cutonce:loader-load (strcat src "CutOnce-Guard.lsp"))
              (cutonce:loader-load (strcat src "CutOnce-ControlCenter.lsp"))))
        (T (princ (strcat "\n[CutOnce] CutOnce.vlx is missing from " home)))
      )
      (if (boundp '*cutonce:version*)
        (princ (strcat "\nCutOnce " *cutonce:version* " loaded (EXPLODE warning only). Type CUTONCE for settings."
                       "\nTo unlock the full version, reach out to stevewalz@hotmail.com"))
      )
    )
  )
  (princ)
)

;; once per drawing, even if both the bundle and an acaddoc.lsp line load it
(if (not (boundp '*cutonce:loaded*))
  (progn
    (setq *cutonce:loaded* T)
    (cutonce:loader-main)
  )
)
(princ)
